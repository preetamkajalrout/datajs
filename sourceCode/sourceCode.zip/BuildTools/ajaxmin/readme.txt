To enable the DataJS library to be minified, download the Ajax Minifier from
http://ajaxmin.codeplex.com/ and copy the binaries into %DJSROOT%\BuildTools\ajaxmin
