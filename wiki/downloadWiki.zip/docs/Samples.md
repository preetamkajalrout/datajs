# Samples
This page provides links to samples available online that you can use to learn more about datajs.

* [Read Data Sample](Read-Data-Sample)
* [Local Service Sample](Local-Service-Sample)
* [Metadata Generation Sample](Metadata-Generation-Sample)
* [Simple CRUD Sample](Simple-CRUD-Sample)
* [Linked Data Sample](Linked-Data-Sample)
* [Master-Detail Sample](Master-Detail-Sample)
* [Storing Preferences Sample](Storing-Preferences-Sample)
* [Cache Grid Sample](Cache-Grid-Sample)
* [Virtual List Sample](Virtual-List-Sample)