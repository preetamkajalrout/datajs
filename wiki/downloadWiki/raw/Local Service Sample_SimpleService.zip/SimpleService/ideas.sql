﻿-- Run this from the command line with:
-- sqlcmd -S .\SQLEXPRESS -E -e -i ideas.sql
-- To drop the database, run sqlcmd -S .\SQLEXPRESS -E -Q "DROP DATABASE IdeasDb;"

CREATE DATABASE IdeasDb;
GO

USE IdeasDb;
GO

CREATE TABLE Categories (
	CategoryID int identity not null primary key,
	Name NVARCHAR(128) NOT NULL,
	CreatedDate datetime NOT NULL DEFAULT GETDATE(),
	CONSTRAINT CategoryNameUnique UNIQUE (Name)
);

CREATE TABLE Ideas (
	IdeaID INT IDENTITY NOT NULL PRIMARY KEY,
	Title NVARCHAR(128) NOT NULL,
	Description NVARCHAR(1024) NOT NULL,
	CreatedDate datetime DEFAULT GETDATE(),
	ClosedDate datetime,
	CONSTRAINT IdeaTitleUnique UNIQUE (Title)
);

CREATE TABLE CategoryIdeas (
	IdeaID INT REFERENCES Ideas(IdeaId),
	CategoryID INT REFERENCES Categories(CategoryId),
	CONSTRAINT CategoryIdeasPK PRIMARY KEY (IdeaID, CategoryID)
);

CREATE TABLE Comments (
	CommentID INT IDENTITY NOT NULL PRIMARY KEY,
	IdeaID INT REFERENCES Ideas (IdeaID),
	CreatedDate datetime NOT NULL DEFAULT GETDATE(),
	Content nvarchar(2048) NOT NULL
);

GO

-- Insert some sample data.
SET IDENTITY_INSERT Categories ON;
INSERT INTO Categories (CategoryID, Name) VALUES (0, N'Other');
INSERT INTO Categories (CategoryID, Name) VALUES (1, N'Features');
INSERT INTO Categories (CategoryID, Name) VALUES (2, N'Process Improvements');
INSERT INTO Categories (CategoryID, Name) VALUES (3, N'Tools');
INSERT INTO Categories (CategoryID, Name) VALUES (4, N'Infrastructure');
INSERT INTO Categories (CategoryID, Name) VALUES (5, N'Quality');
SET IDENTITY_INSERT Categories OFF;
GO

SET IDENTITY_INSERT Ideas ON;
INSERT INTO Ideas (IdeaID, Title, Description)
VALUES (1, N'Add Smile/Frown Buttons', N'This would allow users to send a quick comment from the page, in-context, without logging in.');
INSERT INTO Ideas (IdeaID, Title, Description)
VALUES (2, N'Implement Code Review Checklist', N'We can always do better at having good code reviews. If we had a tool to automate keeping track of who reviews for what, we would minimize missed issues.');
INSERT INTO Ideas (IdeaID, Title, Description)
VALUES (3, N'Monitor From Outside', N'Our servers are monitored from within, not from outside the server lab. We might miss connectivity issues with our current approach.');
INSERT INTO Ideas (IdeaID, Title, Description)
VALUES (4, N'Ice Cream Cake', N'When we ship our next version, we should definitely have some to celebrate.');
INSERT INTO Ideas (IdeaID, Title, Description)
VALUES (5, N'Profit', N'Consider skipping first steps completely...');
SET IDENTITY_INSERT Ideas OFF;
GO

INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (1, 1);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (1, 5);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (2, 2);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (2, 3);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (3, 4);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (3, 5);
INSERT INTO CategoryIdeas (IdeaID, CategoryID) VALUES (4, 0);
GO

SET IDENTITY_INSERT Comments ON;
INSERT INTO Comments (CommentID, IdeaID, Content)
VALUES (1, 2, N'We have checklists on our wiki that can be used as a starting point.');
INSERT INTO Comments (CommentID, IdeaID, Content)
VALUES (2, 4, N'I think chocolate would be best.');
INSERT INTO Comments (CommentID, IdeaID, Content)
VALUES (3, 4, N'I vote for chocolate *and* dulce de leche!');
SET IDENTITY_INSERT Comments OFF;
GO
